package xyz.mxd.wechat.tools;

public interface IEditTextChangeListener {

    void textChange(boolean isHasContent);


}
