package xyz.mxd.wechat.axin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AxinApplication {

    public static void main(String[] args) {
        SpringApplication.run(AxinApplication.class, args);
    }

}
