package xyz.mxd.wechat.axin.entity;

import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;



/**
 * Created by DELL(mxd) on 2021/10/16 10:53
 */
@TableName(value = "user")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class User {

//    @TableId
    private int id;
    private String number;
    private String name;
    private String password;
    private String phone;
//    @TableField(insertStrategy = FieldStrategy.NOT_EMPTY)
    private String remark = "A信";

}
