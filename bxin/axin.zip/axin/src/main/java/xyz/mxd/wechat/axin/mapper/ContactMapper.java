package xyz.mxd.wechat.axin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import xyz.mxd.wechat.axin.entity.Contact;

/**
 * Created by DELL(mxd) on 2021/10/16 15:14
 */
@Mapper
public interface ContactMapper extends BaseMapper<Contact> {
}
