package xyz.mxd.wechat.axin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import xyz.mxd.wechat.axin.entity.WeixinList;

/**
 * Created by DELL(mxd) on 2021/10/16 14:25
 */
@Mapper
public interface wexinlistMapper extends BaseMapper<WeixinList> {
}
