package xyz.mxd.wechat.axin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxinApplicationTests {

    @Test
    void contextLoads() {
    }

}
